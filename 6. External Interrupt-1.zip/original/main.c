#include "stm32l476xx.h"
#define EXTI_PIN 13
#define LED_PIN 5



void LED_Init(void){
	
	// Enable the peripheral clock of GPIO Port	
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN;	

	// GPIO Mode: Input(00), Output(01), AlterFunc(10), Analog(11, reset)
	GPIOA->MODER &= ~(3U<<(2*LED_PIN));  
	GPIOA->MODER |= 1U<<(2*LED_PIN);      //  Output(01)
	
	
	// GPIO Output Type: Output push-pull (0, reset), Output open drain (1) 
	GPIOA->OTYPER &= ~(1U<<LED_PIN);       // Push-pull
	
	
	
}



//-------------------------------------------------------------------------------------------
// Toggle LED 
//-------------------------------------------------------------------------------------------
void LED_Toggle(void){
	GPIOA->ODR ^= (1UL<<LED_PIN);
}

void EXTI_Init(void){
	// GPIO Configuration
	RCC->AHB2ENR |=   RCC_AHB2ENR_GPIOCEN;
	
	// GPIO Mode: Input(00, reset), Output(01), AlterFunc(10), Analog(11, reset)
	GPIOC->MODER &= ~(3U<<(2*EXTI_PIN)); //inputs

	// GPIO PUDD: No pull-up, pull-down (00), Pull-up (01), Pull-down (10), Reserved (11)	
	GPIOC->PUPDR &= ~(3U<<(2*EXTI_PIN)); // no pull-up, no pull down
	
	
	// EXIT Interrupt Enable
	NVIC_EnableIRQ(EXTI15_10_IRQn); 
  NVIC_SetPriority(EXTI15_10_IRQn, 0);  
	
	// Connect External Line to the GPIO
	// RCC APB2 peripheral clocks enable register; SYSCFG clock enabled
	RCC->APB2ENR |= RCC_APB2ENR_SYSCFGEN;             
	// SYSCFG external interrupt configuration registers
	SYSCFG->EXTICR[3] &= ~(0xFFU<<4);
	SYSCFG->EXTICR[3] |= (2<<4);
//	SYSCFG->EXTICR[3] &= ~SYSCFG_EXTICR4_EXTI13;     
//	SYSCFG->EXTICR[3] |=  SYSCFG_EXTICR4_EXTI13_PC; 
	
	// Interrupt Mask Register (IMR)
		EXTI->IMR1 |= EXTI_IMR1_IM13;     // 0 = marked, 1 = not masked (i.e., enabled)
	//EXTI->IMR1 |= (1<<13);
	
	// Falling trigger selection register (FTSR)
	EXTI->FTSR1 |= EXTI_FTSR1_FT13;  // 0 = disabled, 1 = enabled
	//EXTI->FTSR1 |= (1<<13);
	
	// Rising trigger selection register (RTSR)
	// EXTI->RTSR1 |= EXTI_RTSR1_RT13;  // 0 = disabled, 1 = enabled
		
}

void EXTI15_10_IRQHandler(void) {  
	int j,i;
	
	// PR: Pending register
	if ((EXTI->PR1 & 1UL<<13) == 1UL<<13) {         //if ((EXTI->PR1 & EXTI_PR1_PIF13) == EXTI_PR1_PIF13)
		
		for (i=0; i<10; i++){
			for(j=0; j<100000; j++);
		  LED_Toggle();
		}
	}
// clear pending bits by writing a 1 to this bit
		EXTI->PR1 |= EXTI_PR1_PIF13;
	  NVIC_ClearPendingIRQ(EXTI15_10_IRQn);
}


int main(void){

		
	LED_Init();
	EXTI_Init();
	while(1);
}

