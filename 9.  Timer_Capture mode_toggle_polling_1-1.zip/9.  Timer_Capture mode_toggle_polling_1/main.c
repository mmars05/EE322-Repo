#include "stm32l476xx.h"

#define LED_PIN    5
#define LED_PORT   GPIOA
#define BUTTON_PIN    1
volatile uint32_t button_press_counter = 0;
void configure_LED_pin(){
// Enable GPIOA clock
    RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN;  

    // Set PA5 as output (on-board LED)
    GPIOA->MODER &= ~(3UL << (LED_PIN * 2));   
    GPIOA->MODER |= (1UL << (LED_PIN * 2));   	
}
void button_pin_Init(){
	// PA.1 
  // Clock is already enabled 
   
	  GPIOA->MODER  	&= ~(0x03 << (2*BUTTON_PIN));   			// Clear bits
		GPIOA->MODER  	|=   0x02 << (2*BUTTON_PIN);      		// Input(00), Output(01), AlterFunc(10), Analog(11)
	
		GPIOA->AFR[0] 	&= ~(0xF << (4*BUTTON_PIN));         // 	AF 1 = TIM2_CH2
		GPIOA->AFR[0] 	|=   0x1 << (4*BUTTON_PIN);          // 	AF 1 = TIM2_CH2
	
	// GPIO Pull-down: No pull-up, pull-down (00), Pull-up (01), Pull-down (10), Reserved (11)
	GPIOA->PUPDR  &= ~(3<<(2*BUTTON_PIN));  // No pull-up, no pull-down
	GPIOA->PUPDR  |= 2U <<(2*BUTTON_PIN);  //  pull-down
}

void configure_timer2_delay(){
	 // Enable TIM2 clock
    RCC->APB1ENR1 |= RCC_APB1ENR1_TIM2EN;

    // Configure TIM2 for 1 Hz overflow based on 4 MHz clock
     TIM2->PSC = 20 - 1;  //frequency = 1kHz
    TIM2->ARR = 200000 - 1;   // counter overflow eavry 1 sec
    TIM2->CNT = 0;                       
    TIM2->CR1 |= TIM_CR1_CEN;  // enable counter
	
}

void TIM2_CH2_IC_Init(){
	   // configure timer2 chanel 2 for input capture mode
	   TIM2->CCMR1 |= TIM_CCMR1_CC2S_0; // ((uint32_t)0x0000 0100U) Timer2 ch2 is configured as an input
    //TIM2->CCER |= TIM_CCER_CC2P; // ((uint32_t)0x0000_0020U) capture on falling edge  
	     TIM2->CCER &= ~TIM_CCER_CC2P; // ((uint32_t)0x0000_0020U) capture on raising edge
	   TIM2->CCER |= TIM_CCER_CC2E; // ((uint32_t)0x00000010U)  enable ch2 capture  
// enable capture/compare chanal interupt, UIE is not enabled
		TIM2->DIER |= TIM_DIER_CC2IE; // ((uint32_t)0x0000 0004U)  
}	
void TIM2_IRQHandler (){
	// is capture interupt flag of channel 2 is set
	if (TIM2->SR & TIM_SR_CC2IF){
		  TIM2->SR &= ~ TIM_SR_CC2IF; // clear the interrupt flag
		  while (GPIOA->IDR & 1<< BUTTON_PIN){   // is the switch still clicked?
				button_press_counter++;            // if yes increment counter
			}
			                                      // if switch is released
			TIM2->ARR = button_press_counter;   // update the ARR register
			button_press_counter=0;            // reset button press counter
			TIM2->EGR |= TIM_EGR_UG;            // force an update event ((uint32_t)0x00000001U)            
	}
		}


int main(void) {
    
	configure_LED_pin();
	configure_timer2_delay();
	button_pin_Init();
	TIM2_CH2_IC_Init();
	NVIC_EnableIRQ(TIM2_IRQn); 
	    while (1) {
        while (!(TIM2->SR & TIM_SR_UIF)) {}  // wait until timer overflow
        TIM2->SR &= ~TIM_SR_UIF;             // clear flag, it should be cleared otherwise it remains ON
        GPIOA->ODR ^= (1UL << 5);            
    }
}

